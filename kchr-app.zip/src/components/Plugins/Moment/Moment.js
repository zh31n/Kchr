import Vue from 'vue'
import Moment from 'moment'

Moment.locale('ru')
Vue.prototype.$moment = Moment
