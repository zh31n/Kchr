import Vue from 'vue'
import DatePicker2 from 'vue2-datepicker'
import 'vue2-datepicker/index.css'
import 'vue2-datepicker/locale/ru'

Vue.component('datepicker', DatePicker2)
