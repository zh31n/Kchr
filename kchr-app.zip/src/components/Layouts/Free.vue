<template>
  <div class="free-wrapper">
    <router-view/>
  </div>
</template>

<script>

export default {
  name: 'free-layout',
  data: function () {
    return {}
  },
  async mounted () {
  },
  computed: {},
  methods: {}
}
</script>
