<template>
  <div class="footer-wrapper">
    <b>Kchr.ru</b> - Дополнительные услуги
  </div>
</template>

<script>

export default {
  data: function () {
    return {}
  },
  async mounted () {
  },
  computed: {},
  methods: {}
}
</script>
